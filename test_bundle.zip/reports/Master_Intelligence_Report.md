# Master Intelligence Report: OWASPWebGoatPHP_master

## 1. Executive Command Center

**Global System Meta-Data**
- **Scale:** 1324 Files | 847 Classes
- **Architecture/Era:** Custom Legacy Monolith (Bespoke / Custom Era)
- **Modernization Readiness:** 29.48%
- **Test Coverage:** N/A
- **Lines of Code:** 119613
- **Connectivity:** 36307 Edges

**Architectural Footprint**
- Models: 51
- Controllers: 0
- CLI_Scripts: 342
- Schemas: 10
- Views: 63
- Vendor_Files: 33


**AI Executive Assessment**
*Current State:* The Strata Analysis monolith is a sizable legacy codebase with 1324 files totalling roughly 120k lines of code. It contains 51 model classes, no explicit controller layer and 63 view templates, reflecting a tightly coupled MVC pattern that predates modern frameworks. Namespace adoption is effectively nonexistent – the entire project source is written without PSR‑4 namespaces, which explains the Namespace Score of 0.0 and forces every class to live in the global scope, complicating autoloading and static analysis.
Structural debt is pronounced: the overall Coupling Score of 14.98 signals extreme inter‑module dependencies, while the WMC values for key Doctrine components exceed 300, indicating heavyweight business logic and a lack of modular boundaries. LCOM approaching 0.9 for the same files shows poor cohesion, and test coverage is at 0.0%, meaning any change is high‑risk. The hotspot list highlights three Doctrine classes with massive complexity, high instability and zero test protection, all of which sit at the data‑access layer and form a critical failure point.
*Critical Risks:* The most urgent dangers stem from the zero scores in security, testability and namespace use. With a Security Score of 0.0 the codebase lacks input sanitisation and parameterised queries, exposing it to SQL injection attacks – the identified sinks in the app, _japp and files modules confirm this exposure. Testability at 0.0% means defects cannot be detected early, raising operational risk for any refactor or feature addition. The absence of namespaces forces a flat class hierarchy that hampers static analysis, refactoring and modern dependency injection, further entangling the already high coupling. The hotspot classes (Doctrine\DBAL\Connection, AbstractPlatform, UnitOfWork) combine extreme complexity, near‑total instability and no test coverage, creating a single point of catastrophic failure for data integrity and performance.
*Strategic Roadmap:* 
[{'step_number': 1, 'title': 'Establish a Secure, Namespaced Foundation', 'description': 'Introduce PSR‑4 autoloading and refactor core files into a namespaced layer. Apply a modern sanitisation library and enforce prepared statements across all data‑access points, starting with the identified security sinks in app, _japp and files modules.', 'rationale': 'Namespacing restores autoloading efficiency and enables static analysis tools, while immediate input sanitisation mitigates the immediate SQL injection risk and builds a secure baseline for all further work.'}, {'step_number': 2, 'title': 'Isolate and Replatform High‑Risk Data Layer', 'description': 'Extract the Doctrine hotspot components into a dedicated microservice or migrate them to a modern ORM within a new framework. Replace the monolithic UnitOfWork, Connection and AbstractPlatform logic with curated, test‑covered equivalents, and add comprehensive unit and integration tests.', 'rationale': 'Reducing the complexity and instability of the data layer cuts coupling, improves cohesion and provides the first reliable test surface, directly addressing the highest coupling and complexity metrics.'}, {'step_number': 3, 'title': 'Implement Automated Test Suite and Gradual Module Rehost', 'description': 'Build a CI pipeline with unit, integration and security tests covering the newly namespaced core and replatformed data service. Then rehost the stable modules (Core/Root, challenges, script, style, install, template) onto a lightweight modern framework while keeping them functionally intact.', 'rationale': 'A robust test suite locks down regression risk, enabling safe incremental migration of remaining modules and delivering measurable ROI through reduced maintenance overhead and improved system resilience.'}]

## 2. Boundary Intelligence & External Surface


### Presentation Layer Coupling
- **Global UI Entanglement:** 11.4%
- **Fat Views (DB Coupled):** 4

| File | Entanglement Ratio | DB Queries | Fat View Risk |
| :--- | :--- | :--- | :--- |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/panel/dashboard.php` | 84.6% | 11 | CRITICAL |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/edit.php` | 84.1% | 1 | CRITICAL |
| `/data/OWASPWebGoatPHP-master/app/model/j/widget.php` | 19.5% | 1 | CRITICAL |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/panel/development/options.php` | 50.0% | 1 | CRITICAL |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/challenges/__catch.php` | 8.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/plain_text.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/500.php` | 75.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/javascript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/system-interface-not-found.php` | 83.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/challenges/single/XPATHInjection/employees.xml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-elastic_tabstops_lite.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsFoldedScalars.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-solarized_light.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-tas.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/xuser/login.php` | 84.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-nix.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/401.php` | 75.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jsx.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/bootstrap-datetimepicker.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-lisp.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-r.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-dart.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow_night_bright.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/livescript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-vala.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/groovy.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/contest.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/_internal/test/result/cli.php` | 75.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-tcl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/aqua/theme.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-space.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfMergeKey.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/main.php` | 92.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/challenges/single/JSObfuscation/static/obfuscator.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-vhdl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/scheme.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jsx.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/lsl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/admin.php` | 11.8% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-clj.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-clouds_midnight.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-system.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/clojure.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/_internal/test/result/web.php` | 60.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-c_cpp.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-stylus.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-xml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-makefile.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsTypeTransfers.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/objectivec.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-glsl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/textarea.php` | 66.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsAnchorAlias.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/erlang.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/challenges/single/XSS3/static/xss.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-scheme.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/html.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/mushcode.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/coffee.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-chromevox.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-logiql.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/challenges/single/XSS1/static/xss.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-n.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/mysqli.data.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/csrf.php` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-yaml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/bootstrap.min.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/css.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/gitignore.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jade.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/abap.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-django.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-vb.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-go.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-rdoc.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/jquery.reveal.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-win2k-cold-2.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/pdo_sqlite.data.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/velocity.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/dot.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-merbivore_soft.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-settings_menu.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/vbscript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/400.php` | 75.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/toml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-basic.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-mumps.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-terminal.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-json.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ini.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-properties.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/golang.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/curly.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/liquid.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsFlowCollections.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/pdo_mysql.data.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/asciidoc.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/fieldset.php` | 83.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ejs.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/sass.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfComments.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/django.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-pgsql.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/stylus.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/postgre.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/widget.php` | 60.6% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/501-invalid-request.php` | 83.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/test-interface-not-found.php` | 83.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-asciidoc.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-ml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ruby.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/workshop/admin.php` | 85.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-liquid.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/apache_conf.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/lisp.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-d.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/radio.php` | 77.8% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/print.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsBasicTests.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/404-file-not-found.php` | 75.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/pdo_mysql.schema.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/unassign.php` | 85.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-win2k-1.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-sh.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/workshop.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/scss.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-assembly_x86.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/user/get.php` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow_night_eighties.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/rhtml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-golang.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/rust.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/smarty.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/mysql.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/mysqli.test.schema.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/handlebars.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/workshop/challenges/__catch.php` | 77.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-css.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-kr.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/editpermission.php` | 78.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-win2k-2.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/user/logout.php` | 84.6% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-tex.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-csharp.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-latex.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-coffee.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/autolist.php` | 59.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsSpecificationExamples.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/json.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-protobuf.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-statusbar.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/contest/home.php` | 76.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/haskell.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-merbivore.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfCompact.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jsp.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-abap.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/panel/development/registry.php` | 66.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-svg.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-xquery.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/style.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/challenges.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ada.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/glsl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-coldfusion.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfQuotes.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-wiki.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/signin.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-handlebars.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/autoform.php` | 76.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/lang/cn_utf8.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/jquery-3.1.0.min.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/online.php` | 72.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-whitespace.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/about.php` | 92.9% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/captcha.php` | 68.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/config/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/jalali.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-applescript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-rust.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-lua.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ini.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/control/user/create.php` | 20.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/pascal.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/calendar-setup.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-textarea.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/julia.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/properties.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-groovy.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/lucene.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-blue2.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-pastel_on_dark.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/bootstrap-theme.min.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/404.php` | 80.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/bootstrap-theme.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-plain_text.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-apache_conf.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/index.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-old_ie.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/challenges/single/SameOriginPolicy/static/request.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/applescript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/panel/development/translate.php` | 76.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-sql.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/diff.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/sh.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/keybinding-emacs.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/snippets.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-javascript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-linking.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-haskell.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-blue.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/service/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/flipclock.min.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-pascal.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-prolog.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-pascal.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/mobile/main.php` | 75.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-html.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/textile.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/editrole.php` | 78.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-haxe.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/jquery-2.1.1.min.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-matlab.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-idle_fingers.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/contest/challenges/__catch.php` | 85.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/flipclock.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-erlang.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-r.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/reveal.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/test/selenium/loginTest.xml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/r.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/latex.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-llvm.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/matlab.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/_internal/error.php` | 60.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/service-not-found.php` | 83.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow_night_blue.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/addpermission.php` | 78.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/makefile.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-velocity.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/features.php` | 66.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jsoniq.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/base.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-green.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/protobuf.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/cirru.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/vhdl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-error_marker.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/rdoc.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-tex.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/escapedCharacters.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/composer.json` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/403.php` | 75.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/soy_template.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfObjects.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsNullsAndEmpties.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/_template/foot.php` | 77.8% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-objectivec.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-autohotkey.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-searchbox.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/control/mode/contest/user/update.php` | 57.1% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/main.php` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/user/create.php` | 38.5% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/python.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/dart.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-sass.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ocaml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-rd.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-dawn.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/xml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/_template/head.php` | 83.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-textmate.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/luapage.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-win2k-cold-1.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/addrole.php` | 78.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-emmet.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-github.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/mariadb.data.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-markdown.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-snippets.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/logs/view.php` | 76.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/init.php` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/pgsql.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/cobol.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-powershell.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/dashboard.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/autohotkey.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/bootstrap-datetimepicker.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-forth.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/less.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/c9search.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-luapage.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/d.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/single/challenges/__catch.php` | 79.4% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-hs.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/contest-admin.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-mono_industrial.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/sql.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-xquery.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-solarized_dark.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-lua.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-lsl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-gitignore.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/401-authentication-required.php` | 83.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-ambiance.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/contest/admin.php` | 86.8% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/keybinding-vim.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-eclipse.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/input.php` | 69.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/logiql.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/lua.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-dreamweaver.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/db/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-cobol.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-sjs.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-clojure.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-vhdl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-apollo.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-clouds.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-json.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jade.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfTests.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-php.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-twig.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/unassign.php` | 85.4% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/perl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/sjs.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-css.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-themelist.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-curly.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/501.php` | 75.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-yaml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/java.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-xq.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-modelist.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-verilog.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/config/setup.php` | 66.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/yaml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/actionscript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-erlang.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/user/login.php` | 70.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/composer.json` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jsp.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ftl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/_template/foot.php` | 83.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-katzenmilch.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/lang/calendar-en.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/scala.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/control/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-language_tools.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/submit.php` | 66.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-scala.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-lucene.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/svg.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-chaos.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-chrome.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-scala.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Util/Debug.php` | 6.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/unindentedCollections.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ocaml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-actionscript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-split.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-less.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ftl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-soy_template.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/mysqli.schema.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/markdown.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-tcl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-keybinding_menu.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/nix.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-java.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-vibrant_ink.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/pdo_sqlite.schema.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/challenges/single/HTTPOnly/static/cookie.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/dockerfile.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/moment.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/assign.php` | 91.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-diff.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/prettify.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/modules/add.php` | 83.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/tcl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/text.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/remove.php` | 78.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ada.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ejs.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-dockerfile.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-scss.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/typescript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/verilog.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-mushcode.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ace.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/scad.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jsoniq.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/contest/user/signup.php` | 75.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/control/mode/single/challenges/__catch.php` | 7.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/batchfile.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-coffee.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-spellcheck.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-vbscript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/challenges/single/XSS2/static/xss.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/control/mode/contest/ajax/challenge.php` | 12.5% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-xcode.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-matlab.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/forth.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ruby.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/gherkin.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-sql.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/dropdown.php` | 66.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-batchfile.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/deleterole.php` | 78.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/xquery.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/space.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/csharp.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-textile.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/assembly_x86.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsErrorTests.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsDocumentSeparator.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-proto.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-lua.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/html_ruby.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-php.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/mel.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/powershell.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/captcha.php` | 18.8% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-scad.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-gherkin.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-lisp.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/twig.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Logging/EchoSQLLogger.php` | 25.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-static_highlight.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jack.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-crimson_editor.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-haml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/deletepermission.php` | 78.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-c9search.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-cobalt.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/add.php` | 91.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/tex.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-kuroir.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-smarty.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/challenges/single/XSS3/static/image.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-toml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-brown.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/style/bootstrap.min.css` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/files/index.php` | 45.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/prolog.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form.php` | 72.2% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/view/default/jform.php` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-mysql.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-livescript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-dot.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsBlockMapping.yml` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-rhtml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Printer.php` | 33.3% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-perl.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/xuser/reset.php` | 77.8% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/xuser/signup.php` | 78.6% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/challenges/single/ForgotPassword/static/change.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/calendar.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-dart.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-julia.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/model/j/form/upload.php` | 26.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/coldfusion.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-python.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-twilight.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/_template/head.php` | 90.6% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/service/.htaccess` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/user/delete.php` | 44.4% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-typescript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/haxe.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-css.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-html.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-javascript.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jack.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-monokai.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow_night.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/install/_db/mariadb.schema.sql` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-html_ruby.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/vala.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/c_cpp.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/xuser/logout.php` | 80.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/assign.php` | 89.7% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/haml.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-mel.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-cirru.js` | 50.0% | 0 | LOW |
| `/data/OWASPWebGoatPHP-master/script/calendar/lang/calendar-fa.js` | 50.0% | 0 | LOW |


### API & Endpoint Surface
- **Total Endpoints:** 479

| Entry Point | Classification |
| :--- | :--- |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/challenges/__catch.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/plain_text.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/500.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/javascript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/system-interface-not-found.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/XPATHInjection/employees.xml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-elastic_tabstops_lite.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsFoldedScalars.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-solarized_light.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-tas.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/xuser/login.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-nix.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/401.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jsx.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/bootstrap-datetimepicker.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-lisp.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-r.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-dart.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow_night_bright.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/livescript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-vala.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/groovy.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/contest.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-tcl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/aqua/theme.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-space.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/panel/dashboard.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfMergeKey.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/main.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/JSObfuscation/static/obfuscator.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-vhdl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/scheme.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jsx.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/lsl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/admin.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-clj.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-clouds_midnight.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-system.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/clojure.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/DBALException.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-c_cpp.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-stylus.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-xml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-makefile.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsTypeTransfers.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/objectivec.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-glsl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsAnchorAlias.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/erlang.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/XSS3/static/xss.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-scheme.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/html.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/mushcode.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/coffee.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-chromevox.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-logiql.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/XSS1/static/xss.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-n.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/mysqli.data.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-yaml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/bootstrap.min.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/css.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/gitignore.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jade.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/abap.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-django.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-vb.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/JsonArrayType.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-go.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-rdoc.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/jquery.reveal.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-win2k-cold-2.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/pdo_sqlite.data.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/velocity.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/dot.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-merbivore_soft.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-settings_menu.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/vbscript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/400.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/toml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-basic.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-mumps.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-terminal.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-json.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ini.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-properties.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/golang.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/curly.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/liquid.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsFlowCollections.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/pdo_mysql.data.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/asciidoc.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ejs.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/sass.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfComments.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/django.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-pgsql.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/stylus.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/postgre.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/501-invalid-request.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/model/service/output/json.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/test-interface-not-found.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-asciidoc.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-ml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ruby.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/workshop/admin.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-liquid.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/apache_conf.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/lisp.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-d.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/print.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsBasicTests.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/404-file-not-found.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/pdo_mysql.schema.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/unassign.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-win2k-1.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-sh.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/workshop.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/scss.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-assembly_x86.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/user/get.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow_night_eighties.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/rhtml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-golang.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/rust.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/smarty.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/mysql.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/mysqli.test.schema.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/handlebars.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/workshop/challenges/__catch.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-css.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-kr.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/editpermission.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-win2k-2.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/user/logout.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-tex.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-csharp.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-latex.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-coffee.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsSpecificationExamples.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/json.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-protobuf.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-statusbar.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/contest/home.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/haskell.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-merbivore.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfCompact.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jsp.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-abap.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/panel/development/registry.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-svg.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-xquery.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/style.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/challenges.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ada.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/glsl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-coldfusion.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfQuotes.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-wiki.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/signin.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-handlebars.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/lang/cn_utf8.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/jquery-3.1.0.min.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/online.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-whitespace.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/about.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/config/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/jalali.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-applescript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-rust.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-lua.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ini.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/pascal.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/calendar-setup.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-textarea.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/julia.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/properties.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/model/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-groovy.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/lucene.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-blue2.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-pastel_on_dark.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/bootstrap-theme.min.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/404.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/bootstrap-theme.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/edit.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-plain_text.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-apache_conf.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/index.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-old_ie.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/SameOriginPolicy/static/request.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/applescript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/panel/development/translate.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-sql.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/diff.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/sh.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/DocParser.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/keybinding-emacs.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/snippets.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-javascript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-linking.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-haskell.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-blue.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/service/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/flipclock.min.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-pascal.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-prolog.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-pascal.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/mobile/main.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-html.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/textile.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/editrole.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-haxe.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/jquery-2.1.1.min.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-matlab.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-idle_fingers.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/contest/challenges/__catch.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/flipclock.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-erlang.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-r.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/reveal.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/test/selenium/loginTest.xml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/r.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/latex.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-llvm.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/matlab.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/service-not-found.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow_night_blue.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/addpermission.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/makefile.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-velocity.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/features.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jsoniq.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/base.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-green.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/protobuf.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/cirru.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/vhdl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-error_marker.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/rdoc.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-tex.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/escapedCharacters.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/composer.json` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/403.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/soy_template.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfObjects.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsNullsAndEmpties.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/_template/foot.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-objectivec.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-autohotkey.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-searchbox.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/control/mode/contest/user/update.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/main.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/user/create.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/python.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/dart.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-sass.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ocaml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-rd.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-dawn.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/xml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/_template/head.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-textmate.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/luapage.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-win2k-cold-1.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/addrole.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-emmet.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-github.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/mariadb.data.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-markdown.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-snippets.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/logs/view.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/init.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/pgsql.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/cobol.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-powershell.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/dashboard.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/autohotkey.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/bootstrap-datetimepicker.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-forth.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/less.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/c9search.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-luapage.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/d.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/single/challenges/__catch.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-hs.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/contest-admin.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-mono_industrial.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/sql.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-xquery.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-solarized_dark.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-lua.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-lsl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-gitignore.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/401-authentication-required.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-ambiance.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/contest/admin.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/keybinding-vim.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-eclipse.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/logiql.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/lua.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-dreamweaver.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/db/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-cobol.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-sjs.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-clojure.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-vhdl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-apollo.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-clouds.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-json.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jade.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfTests.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-php.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-twig.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/unassign.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/perl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/sjs.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-css.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-themelist.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-curly.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/_internal/error/501.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-yaml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/java.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-xq.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-modelist.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-verilog.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/config/setup.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/yaml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/actionscript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-erlang.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/user/login.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/composer.json` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jsp.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ftl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/_template/foot.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-katzenmilch.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/lang/calendar-en.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/scala.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/control/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-language_tools.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-scala.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-lucene.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/svg.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-chaos.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-chrome.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-scala.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/unindentedCollections.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ocaml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-actionscript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-split.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-less.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ftl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-soy_template.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/mysqli.schema.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/markdown.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-tcl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-keybinding_menu.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/nix.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-java.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-vibrant_ink.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/pdo_sqlite.schema.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/HTTPOnly/static/cookie.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/dockerfile.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/moment.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/assign.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-diff.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/prettify.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/modules/add.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/tcl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/text.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/remove.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ada.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-ejs.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-dockerfile.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-scss.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/typescript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/verilog.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-mushcode.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ace.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/scad.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jsoniq.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/mode/contest/user/signup.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/control/mode/single/challenges/__catch.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/batchfile.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-coffee.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-spellcheck.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-vbscript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/XSS2/static/xss.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/control/mode/contest/ajax/challenge.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-xcode.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-matlab.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/forth.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/ruby.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/gherkin.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-sql.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-batchfile.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/deleterole.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/xquery.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/space.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/csharp.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-textile.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/assembly_x86.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Annotation/IgnoreAnnotation.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsErrorTests.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsDocumentSeparator.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-proto.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-lua.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/html_ruby.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-php.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/mel.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/powershell.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-scad.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/model/service/output/jsonp.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-gherkin.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/prettify/lang-lisp.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/twig.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/ext-static_highlight.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/jack.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-crimson_editor.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-haml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/rbac/deletepermission.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-c9search.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-cobalt.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/add.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/tex.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-kuroir.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-smarty.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/XSS3/static/image.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-toml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/skins/calendar-brown.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/style/bootstrap.min.css` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/files/index.php` | Procedural Router |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/prolog.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/view/default/jform.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Exception/ParseException.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-mysql.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-livescript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-dot.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsBlockMapping.yml` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-rhtml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-perl.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/xuser/reset.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/xuser/signup.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/ForgotPassword/static/change.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/calendar.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-dart.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-julia.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/coldfusion.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-python.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-twilight.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/_template/head.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/service/.htaccess` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/panel/development/options.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/app/control/mode/workshop/user/delete.php` | API Endpoint |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-typescript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/haxe.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-css.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-html.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/worker-javascript.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-jack.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-monokai.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/theme-tomorrow_night.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/install/_db/mariadb.schema.sql` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-html_ruby.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/vala.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/c_cpp.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/xuser/logout.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/_japp/view/default/users/assign.php` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/challenges/single/SessionFixation/index.php` | Procedural Router |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/snippets/haml.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-mel.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/ace/src-min-noconflict/mode-cirru.js` | Server-Rendered Page |
| `/data/OWASPWebGoatPHP-master/script/calendar/lang/calendar-fa.js` | Server-Rendered Page |


### Vendor & Shadow IT Intelligence
- **Vendor Files Scanned:** 693

| File | Vendor Type | Status |
| :--- | :--- | :--- |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/ParserTest.php` | Symfony | 🔴 ORPHANED RISK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/DumperTest.php` | Symfony | 🔴 ORPHANED RISK |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/nusoap/nusoap.php` | Manual Library/Plugin | 🔴 ORPHANED RISK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Application.php` | Symfony | 🔴 ORPHANED RISK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/security/password.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Literal.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/SQLParserUtils.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/ConversionException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/NamedQuery.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/JoinColumns.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Exec/AbstractSqlExecutor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Util/Inflector.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/JoinAssociationDeclaration.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/Expr/Value.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsFoldedScalars.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/AbstractPlatform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/DiscriminatorColumn.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/ReflectionService.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Input/InputOption.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/SchemaConfig.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Proxy/ProxyException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/ConnectionRegistry.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Formatter/OutputFormatterInterface.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/LocateFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Lexer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/RangeVariableDeclaration.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Event/PreUpdateEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Id/BigIntegerIdentityGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Formatter/OutputFormatterTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/PhpParser.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/YamlDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/OCI8/OCI8Statement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/FloatType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Internal/Hydration/ObjectHydrator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Portability/Statement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/DateAddFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/SchemaTool/AbstractCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/SingleTablePersister.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/PersistentObject.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/NamingStrategy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/DeleteStatement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Sharding/PoolingShardManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/Driver/FileLocator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Join.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfMergeKey.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/AnnotationRegistry.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Exception/DumpException.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/LikeExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/SimpleWhenClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/Expr/Expression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/SQLAzurePlatform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/plugin/main.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/NamedNativeQueries.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/OCI8/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/rbac/base.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/CommonException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ArithmeticTerm.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/TextType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/SchemaDiff.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaCreateTableColumnEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/DBALException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/SQLSrv/SQLSrvStatement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsTypeTransfers.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/GeneralCaseExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/IBMDB2/DB2Connection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsAnchorAlias.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/CacheProvider.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ConditionalPrimary.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Reflection/ReflectionProviderInterface.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/SqliteSchemaManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Pagination/WhereInWalker.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Event/PreUpdateEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/TreeWalkerAdapter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Reflection/StaticReflectionParser.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Pagination/Paginator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/WhereClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/SqlExpressionVisitor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/Keywords/DrizzleKeywords.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/db.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Internal/Hydration/ScalarHydrator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/OrderBy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Portability/Connection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/CurrentTimeFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/ParameterTypeInferer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/Keywords/KeywordList.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/ResolveTargetEntityListener.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/CurrentDateFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/ToolsException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Internal/Hydration/HydrationException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Internal/Hydration/SimpleObjectHydrator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ExistsExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/Type.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Internal/Hydration/SingleScalarHydrator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Event/GenerateSchemaEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/NoResultException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/JsonArrayType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/Mysqli/MysqliStatement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Output/StreamOutput.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Command/HelpCommand.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/BitOrFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/UnitOfWork.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/EnsureProductionSettingsCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/MySqlPlatform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/Expr/Comparison.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/SchemaTool/DropCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Event/LifecycleEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/security/password.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Internal/Hydration/AbstractHydrator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Export/Driver/AnnotationExporter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/InExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Fixtures/Foo3Command.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Fixtures/Foo1Command.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaAlterTableRenameColumnEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/SQLServerPlatform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Builder/FieldBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/PersistentCollection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Helper/HelperSet.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Math.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/ElementCollectionPersister.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/ZendDataCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Parser.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Events.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Visitor/RemoveNamespacedAssets.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Configuration.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/plugin/jalali.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/Expr/CompositeExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/ClearCache/ResultCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/IdentityFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Event/LifecycleEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Table.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/StaticPHPDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/db/adapter/mariadb.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/Driver/PHPDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsFlowCollections.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/ORMInvalidArgumentException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/PreUpdate.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/EntityGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/Listeners/SQLSessionInit.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Pagination/LimitSubqueryWalker.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/bin/doctrine-pear.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/Listeners/MysqlSessionInit.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/BlobType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/ClassMetadata.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfComments.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/test/plugin/autoform.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Event/LoadClassMetadataEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/Mysqli/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/EventSubscriber.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Sequence.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Parameter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/Cache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Input/ArrayInput.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaAlterTableAddColumnEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/PartialObjectExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Comparison.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/RedisCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Statement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/rbac/users.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/lastrss.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/NotifyPropertyChanged.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Subselect.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/DocLexer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/SubselectFromClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/stats.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/SimpleSelectClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/RuntimeReflectionService.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/NonUniqueResultException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/DisconnectedClassMetadataFactory.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/AbstractEntityInheritancePersister.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/SimpleArithmeticExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Command/HelpCommandTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/helper.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/BetweenExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/ManyToManyPersister.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/db/adapter/base.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/useragent/mobile.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Input/InputArgument.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsBasicTests.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/SQLSrv/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/GenerateEntitiesCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/SchemaTool/CreateCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/GeneratedValue.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/ClearCache/QueryCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Base.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/OraclePlatform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/DrizzlePDOMySql/Connection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ConditionalFactor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Input/StringInputTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/SchemaException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Cache/ArrayStatement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Id/SequenceGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/EntityNotFoundException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/UpdateClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Output/NullOutput.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Inline.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Input/InputArgumentTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Input/InputDefinitionTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/TreeWalker.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Node.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Util/ClassUtils.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/IndexedReader.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Output/OutputInterface.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/MemcachedCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Lexer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Reflection/ClassFinderInterface.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Reflection/StaticReflectionProperty.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/ObjectRepository.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/SqlWalker.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/AbstractClassMetadataFactory.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/ChangeTrackingPolicy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/OracleSchemaManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/phpunit/loader.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Annotation/Attribute.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/ConvertMappingCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/xuser.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/SimplifiedYamlDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Pagination/CountOutputWalker.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/autolist.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Tools/Console/Helper/ConnectionHelper.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Export/Driver/YamlExporter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsSpecificationExamples.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/db/adapter/main.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/DateDiffFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Annotation/Target.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ArithmeticExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/db/adapter/mysqli.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/IBMDB2/DB2Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfCompact.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Table.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/IndexBy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/BitAndFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Output/ConsoleOutputTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/SimpleAnnotationReader.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Input/InputDefinition.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/XcacheCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/GroupByClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/PDOConnection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Command/ListCommandTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/ClassMetadataFactory.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaColumnDefinitionEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Command/ListCommand.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/DebugUnitOfWorkListener.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Unescaper.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Output/OutputTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfQuotes.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/SimpleCaseExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/xuser.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/DrizzleSchemaManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/ConsoleRunner.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/SchemaTool.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ArithmeticFactor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Connections/MasterSlaveConnection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/ClassLoader.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/MsSqlSchemaManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/autoform.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Synchronizer/SchemaSynchronizer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Version.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/ManyToMany.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Event/LoadClassMetadataEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/captcha.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/OrderBy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Formatter/OutputFormatterStyle.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Constraint.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/ConnectionEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/bootstrap.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Sharding/SQLAzure/SQLAzureShardManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/EntityManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/PhpFileCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/.htaccess` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/AnnotationDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/Connection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/JoinColumn.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/HasLifecycleCallbacks.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/Collection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Sharding/SQLAzure/SQLAzureFederationsSynchronizer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/DefaultQuoteStrategy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/TransactionRequiredException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/ModFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/ManyToOne.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/SmallIntType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/ConcatFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/AttributeOverrides.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/UnderscoreNamingStrategy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/QuantifiedExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/PrePersist.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Logging/DebugStack.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Builder/OneToManyAssociationBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/AbstractAsset.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/UpdateStatement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/SQLServerSchemaManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/PDOIbm/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Query/Expression/ExpressionBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/index.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Annotation/Attributes.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Parser.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/DeleteClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/CachedReader.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/WinCacheCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/Driver/MappingDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/GroupBy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/PessimisticLockException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/NamedNativeQuery.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/JoinVariableDeclaration.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Pagination/LimitSubqueryOutputWalker.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/PDOSqlsrv/Connection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/SelectExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/AssociationOverrides.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Comparator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/DocParser.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/rbac/base.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/SimplifiedXmlDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Version.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/SqlValueVisitor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Tools/Console/Command/ReservedWordsCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/ArrayCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/profiler.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/EntityRepository.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/MetadataFilter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/SQLServer2008Platform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/view/parser.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Input/Input.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/UnionSubclassPersister.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/ClearCache/MetadataCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/PreFlush.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/sqllogger.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/AbsFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Fixtures/TestCommand.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Query/Expression/CompositeExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/PreRemove.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/MappingException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/Driver/FileDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Export/Driver/AbstractExporter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/Driver/AnnotationDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Func.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/QuoteStrategy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/GenerateProxiesCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Export/ExportException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Setup.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Id/TableGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/ArrayCollection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/OneToMany.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/Statement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/db/adapter/mariadb.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Helper/EntityManagerHelper.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/SqlitePlatform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Visitor/Graphviz.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/EmptyCollectionComparisonExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/FileCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/AbstractSchemaManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/Mysqli/MysqliException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/MappingException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Input/InputTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaAlterTableEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/TrimFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/ConvertDoctrine1SchemaCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Reader.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Id/IdentityGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/Driver/StaticPHPDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Output/ConsoleOutput.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/SelectStatement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/rbac/roles.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ComparisonExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Index.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/CustomIdGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Id/TableGeneratorSchemaVisitor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Visitor/DropSchemaSqlCollector.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/GenerateRepositoriesCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/escapedCharacters.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Synchronizer/AbstractSchemaSynchronizer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/composer.json` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfObjects.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsNullsAndEmpties.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/PDOStatement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/OCI8/OCI8Exception.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Version.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Tester/CommandTesterTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/Expr/ExpressionVisitor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/rbac/roles.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Sharding/ShardManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/ApplicationTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/AnnotationException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Output/NullOutputTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/InlineTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/InstanceOfExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/JoinAssociationPathExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Builder/ClassMetadataBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Command/CommandTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Exec/SingleTableDeleteUpdateExecutor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Tester/ApplicationTesterTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/db/base.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaAlterTableRemoveColumnEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Column.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/ColumnResult.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/DriverManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/InputParameter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/PostLoad.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Export/Driver/PhpExporter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/Listeners/OracleSessionInit.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/AssociationOverride.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/rbac/main.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Connection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/Keywords/PostgreSQLKeywords.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/Mysqli/MysqliConnection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Query/QueryBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Command/Command.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/AggregateExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/Expr/ClosureExpressionVisitor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/WhenClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/IBMDB2/DB2Statement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/InfoCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/ArrayType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/bootstrap.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Input/StringInput.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Yaml.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Proxy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/db/adapter/pdo_mysql.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Id/AssignedGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/rbac/users.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/DatabaseDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/Keywords/DB2Keywords.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/PHPDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Proxy/Autoloader.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/StaticReflectionService.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Reflection/Psr0FindFile.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/DB2Platform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/TableDiff.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/SizeFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/OneToOne.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/FieldResult.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/LowerFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Logging/SQLLogger.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/PathExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/SubstringFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/AttributeOverride.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/ORMException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/NamedQueries.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Parser.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Helper/DialogHelper.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Sharding/ShardChoser/MultiTenantShardChoser.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Fixtures/FooCommand.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/DecimalType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/PDOSqlite/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/db/adapter/mssql.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/XmlDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/SQLServer2005Platform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Builder/ManyToManyAssociationBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Extensions/TablePrefix.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Input/InputOptionTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Helper/DialogHelperTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/PostUpdate.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Sharding/SQLAzure/Schema/MultiTenantVisitor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/ObjectManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/DB2SchemaManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaCreateTableEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaIndexDefinitionEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Formatter/OutputFormatter.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/ResultStatement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Formatter/OutputFormatterStyleStack.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/rbac/permissions.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/CollectionMemberExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/CurrentTimestampFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Orx.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/BooleanType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/ObjectType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/Keywords/OracleKeywords.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Filter/SQLFilter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/ClassMetadata.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/FunctionNode.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Builder/AssociationBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/OrderByItem.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/db/adapter/pdo_sqlite.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Event/OnFlushEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Exec/MultiTableUpdateExecutor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Column.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/UnexpectedResultException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/sfTests.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/ToolEvents.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Sharding/PoolingShardConnection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/Keywords/MySQLKeywords.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaDropTableEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/SimpleArrayType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/AbstractQuery.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Literal.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ConditionalExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/View.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/NullIfExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Reflection/StaticReflectionClass.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/DefaultNamingStrategy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Internal/Hydration/ArrayHydrator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/MySqlSchemaManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/HavingClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/MemcacheCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/SQLSrv/LastInsertId.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Join.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Proxy/Proxy.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Annotation.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/ConvertDoctrine1Schema.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/ValidateSchemaCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/phpxml.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/db/nestedset/base.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Visitor/CreateSchemaSqlCollector.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/CoalesceExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/AbstractFileDriver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/ManagerRegistry.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/ApcCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Event/OnClearEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/OrderByClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/settings.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/DrizzlePlatform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/AbstractCollectionPersister.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/PostPersist.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Schema.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/DateTimeType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Lexer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Event/SchemaAlterTableChangeColumnEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/StringType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/composer.json` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/Driver/SymfonyFileLocator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Visitor/Visitor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/OptimisticLockException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Event/ManagerEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/PDOPgSql/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/i18n.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Output/ConsoleOutputInterface.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/PDOSqlsrv/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/GuidType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Shell.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/AbstractCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/PDOMySql/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/ParserResult.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Select.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/ResultSetMapping.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Id/AbstractIdGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Helper/Helper.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/SequenceGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/UpdateItem.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/user.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Util/Debug.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/unindentedCollections.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Configuration.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/RunDqlCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/UniqueConstraint.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Helper/FormatterHelper.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/DateTimeTzType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Exception/ExceptionInterface.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Helper/FormatterHelperTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/NativeQuery.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/SQLSrv/SQLSrvException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/TimeType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ASTException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Input/InputInterface.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Escaper.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/DoctrineAnnotations.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Logging/jFrameworkSQLLogger.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/SimpleSelectExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Cache/CacheException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/JoinTable.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/SqlResultSetMapping.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Sharding/ShardingException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/EventManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/AbstractManagerRegistry.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/MappedSuperclass.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/LockMode.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Event/PreFlushEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Query/QueryException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Tools/Console/Command/ImportCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/jpki/core.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/FromClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/OCI8/OCI8Connection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/ExpressionBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/UpperFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/plugin/.htaccess` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/db/nestedset/full.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Input/ArgvInputTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Fixtures/Foo2Command.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/IdentificationVariableDeclaration.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/AnnotationReader.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/EntityResult.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Output/StreamOutputTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/JoinClassPathExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Id/TableGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/db/adapter/pdo_sqlite.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/DateSubFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/ClassMetadataFactory.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Cache/QueryCacheProfile.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/EventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Annotation.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Reflection/StaticReflectionMethod.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Export/ClassMetadataExporter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Input/ArrayInputTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Annotation/IgnoreAnnotation.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsErrorTests.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/SQLSrv/SQLSrvConnection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsDocumentSeparator.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/JoinedSubclassPersister.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/Keywords/SQLiteKeywords.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/PDOOracle/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Events.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/DrizzlePDOMySql/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Andx.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/ElementCollection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/BigIntType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/ColumnDiff.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Exec/SingleSelectExecutor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/Selectable.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/FileCacheReader.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/Driver/MappingDriverChain.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Logging/EchoSQLLogger.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Tools/Console/Command/RunSqlCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/db/adapter/pdo_mysql.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/QueryException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Cache/FilesystemCache.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/DiscriminatorMap.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/Annotation/Required.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Dumper.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/ForeignKeyConstraint.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Event/OnClearEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/OneToManyPersister.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/DriverChain.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/QueryBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/PropertyChangedListener.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/main.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/ConditionalTerm.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/From.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Persisters/BasicEntityPersister.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Internal/CommitOrderCalculator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Driver/Driver.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/LengthFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Comparable.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/InheritanceType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Event/GenerateSchemaTableEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/PostRemove.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Console/Command/SchemaTool/UpdateCommand.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Input/ArgvInput.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/EntityRepositoryGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/VarDateTimeType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Annotations/TokenParser.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/SelectClause.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/ObjectManagerAware.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Collections/Criteria.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/db/adapter/mysqli.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/DateType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Exception/ParseException.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Index.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/SqlResultSetMappings.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tests/Formatter/OutputFormatterStyleTest.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Yaml/Tests/Fixtures/YtsBlockMapping.yml` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/TreeWalkerChain.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tester/CommandTester.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Exec/MultiTableDeleteExecutor.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Export/Driver/XmlExporter.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/NullComparisonExpression.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/ClassMetadataInfo.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/ResultSetMappingBuilder.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Helper/HelperInterface.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Printer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/AST/Functions/SqrtFunction.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Output/Output.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Persistence/Mapping/Driver/DefaultFileLocator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/model/lib/rbac/permissions.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/jalali.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/Keywords/ReservedKeywordsValidator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/ConnectionException.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/PostgreSqlPlatform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Entity.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Event/PostFlushEventArgs.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/SchemaValidator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Id/UuidGenerator.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Tester/ApplicationTester.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/Expr/Composite.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Types/IntegerType.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Query/FilterCollection.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Tools/Pagination/CountWalker.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/bin/doctrine.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Symfony/Component/Console/Formatter/OutputFormatterStyleInterface.php` | Symfony | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/_japp/test/lib/session.php` | Manual Library/Plugin | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Sharding/ShardChoser/ShardChoser.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Mapping/Id.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Logging/LoggerChain.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Internal/Hydration/IterableResult.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/Common/Version.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/PostgreSqlSchemaManager.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Schema/Synchronizer/SingleDatabaseSynchronizer.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/ORM/Proxy/ProxyFactory.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/MsSqlPlatform.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Driver/IBMDB2/DB2Exception.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Cache/ResultCacheStatement.php` | Doctrine | 🟢 OK |
| `/data/OWASPWebGoatPHP-master/app/plugin/doctrine/Doctrine/DBAL/Platforms/Keywords/MsSQLKeywords.php` | Doctrine | 🟢 OK |



## 3. Layered Architecture & Topology


- **Presentation vs. Logic Ratio:** 6.2204724409448815% of classified files are UI/Routing related.

### Bounded Contexts
| Domain Name | Files | Internal Calls | External Calls | Coupling Ratio | DB Access | Auth Access |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `challenges` | 6 | 0 | 0 | 22.0 | False | False |
| `Doctrine` | 544 | 0 | 0 | 0.13 | False | False |
| `FailOpenAuthentication` | 1 | 0 | 0 | 3.0 | False | False |
| `snippets` | 112 | 0 | 0 | 0.0 | False | False |
| `error` | 12 | 0 | 0 | 4.0 | False | False |
| `XPATHInjection` | 2 | 0 | 0 | 3.0 | False | False |
| `jf` | 27 | 0 | 0 | 0.62 | False | False |
| `control` | 4 | 0 | 0 | 5.0 | False | False |
| `webgoat` | 43 | 0 | 0 | 0.23 | False | False |
| `jchat` | 6 | 0 | 0 | 6.0 | False | False |
| `Global` | 197 | 0 | 0 | 0.6 | False | False |
| `ForgotPassword` | 1 | 0 | 0 | 3.0 | False | False |
| `input` | 11 | 0 | 0 | 11.0 | False | False |
| `src-min-noconflict` | 174 | 0 | 0 | 0.0 | False | False |
| `skins` | 10 | 0 | 0 | 0.0 | False | False |
| `xuser` | 4 | 0 | 0 | 1.0 | False | False |
| `prettify` | 28 | 0 | 0 | 0.0 | False | False |
| `public` | 4 | 0 | 0 | 13.0 | False | False |
| `Symfony` | 67 | 0 | 0 | 0.57 | False | False |
| `LogSpoofing` | 1 | 0 | 0 | 3.0 | False | False |
| `script` | 9 | 0 | 0 | 0.0 | False | False |
| `result` | 2 | 0 | 0 | 34.0 | False | False |
| `aqua` | 1 | 0 | 0 | 0.0 | False | False |
| `panel` | 1 | 0 | 0 | 5.0 | False | False |
| `default` | 6 | 0 | 0 | 8.0 | False | False |
| `static` | 8 | 0 | 0 | 0.0 | False | False |
| `workshop` | 3 | 0 | 0 | 5.0 | False | False |
| `core` | 2 | 0 | 0 | 5.0 | False | False |
| `hook` | 2 | 0 | 0 | 3.0 | False | False |
| `output` | 7 | 0 | 0 | 7.0 | False | False |
| `contest` | 10 | 0 | 0 | 18.0 | False | False |
| `form` | 11 | 0 | 0 | 14.0 | False | False |
| `user` | 13 | 0 | 0 | 22.0 | False | False |
| `test` | 6 | 0 | 0 | 6.0 | False | False |
| `EncodingBasics` | 1 | 0 | 0 | 3.0 | False | False |
| `x509` | 2 | 0 | 0 | 2.0 | False | False |
| `_db` | 10 | 0 | 0 | 0.0 | False | False |
| `service` | 4 | 0 | 0 | 3.0 | False | False |
| `jpki` | 4 | 0 | 0 | 4.0 | False | False |
| `JSObfuscation` | 1 | 0 | 0 | 3.0 | False | False |
| `HiddenFields` | 1 | 0 | 0 | 3.0 | False | False |
| `HTMLClues` | 1 | 0 | 0 | 3.0 | False | False |
| `app` | 2 | 0 | 0 | 3.0 | False | False |
| `style` | 8 | 0 | 0 | 0.0 | False | False |
| `view` | 2 | 0 | 0 | 0.0 | False | False |
| `rbac` | 8 | 0 | 0 | 22.0 | False | False |
| `SameOriginPolicy` | 1 | 0 | 0 | 3.0 | False | False |
| `private` | 2 | 0 | 0 | 2.0 | False | False |
| `ForcedBrowsing` | 1 | 0 | 0 | 3.0 | False | False |
| `PathBasedAccessControl` | 1 | 0 | 0 | 3.0 | False | False |
| `model` | 3 | 0 | 0 | 3.0 | False | False |
| `development` | 3 | 0 | 0 | 1.0 | False | False |
| `lang` | 3 | 0 | 0 | 0.0 | False | False |
| `users` | 6 | 0 | 0 | 3.0 | False | False |
| `AccessControlMatrix` | 1 | 0 | 0 | 3.0 | False | False |
| `config` | 5 | 0 | 0 | 5.33 | False | False |
| `calendar` | 3 | 0 | 0 | 0.0 | False | False |
| `WebGoatIntro` | 1 | 0 | 0 | 2.0 | False | False |
| `WeakAuthenticationCookie` | 1 | 0 | 0 | 4.0 | False | False |
| `mobile` | 1 | 0 | 0 | 0.0 | False | False |
| `selenium` | 1 | 0 | 0 | 0.0 | False | False |
| `_internal` | 1 | 0 | 0 | 10.0 | False | False |
| `HTTPBasics` | 1 | 0 | 0 | 3.0 | False | False |
| `lesson` | 2 | 0 | 0 | 3.0 | False | False |
| `install` | 2 | 0 | 0 | 0.0 | False | False |
| `_template` | 6 | 0 | 0 | 9.0 | False | False |
| `XSS1` | 1 | 0 | 0 | 3.0 | False | False |
| `XSS3` | 1 | 0 | 0 | 3.0 | False | False |
| `logs` | 1 | 0 | 0 | 0.0 | False | False |
| `XSS2` | 1 | 0 | 0 | 3.0 | False | False |
| `base` | 5 | 0 | 0 | 14.0 | False | False |
| `db` | 1 | 0 | 0 | 4.0 | False | False |
| `HTTPOnly` | 1 | 0 | 0 | 3.0 | False | False |
| `UsefulTools` | 1 | 0 | 0 | 2.0 | False | False |
| `j` | 3 | 0 | 0 | 8.0 | False | False |
| `HTMLFieldRestrictions` | 1 | 0 | 0 | 3.0 | False | False |
| `NumericSQLInjection` | 1 | 0 | 0 | 3.0 | False | False |
| `modules` | 1 | 0 | 0 | 1.0 | False | False |
| `ajax` | 1 | 0 | 0 | 2.0 | False | False |
| `files` | 1 | 0 | 0 | 11.0 | False | False |
| `SampleLesson` | 1 | 0 | 0 | 3.0 | False | False |
| `BusinessLayerAccessControl` | 1 | 0 | 0 | 3.0 | False | False |
| `SessionFixation` | 1 | 0 | 0 | 5.0 | False | False |


*(Note: The full interactive system topology graph is available in the accompanying `index.html` application or raw `raw_data/graph_1.json` export).*


## 4. Database & State Intelligence

| Table Name | Write Intensity | Shared Pressure |
| :--- | :--- | :--- |
| `` |  |  |
| `` |  |  |
| `` |  |  |
| `` |  |  |
| `` |  |  |


## 5. Risk Audit & Remediation

### [High] Critical Architectural Bottleneck in Doctrine\DBAL\Connection
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: Doctrine\DBAL\Connection 
- `metric`: risk_score (0.50298)
- `metric`: coupling_pressure (0.4164172231176606)



#### Topology Diagram
```mermaid
graph TD
  Doctrine\DBAL\Connection --> LegacyDependencies
  style Doctrine\DBAL\Connection fill:#f9f,stroke:#333,stroke-width:4px
```

---
### [High] Critical Architectural Bottleneck in Doctrine\DBAL\Platforms\AbstractPlatform
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: Doctrine\DBAL\Platforms\AbstractPlatform 
- `metric`: risk_score (0.54468)
- `metric`: coupling_pressure (0.5767326732673267)



#### Topology Diagram
```mermaid
graph TD
  Doctrine\DBAL\Platforms\AbstractPlatform --> LegacyDependencies
  style Doctrine\DBAL\Platforms\AbstractPlatform fill:#f9f,stroke:#333,stroke-width:4px
```

---
### [High] Critical Architectural Bottleneck in Doctrine\ORM\UnitOfWork
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: Doctrine\ORM\UnitOfWork 
- `metric`: risk_score (0.52542)
- `metric`: coupling_pressure (0.3911466728068156)



#### Topology Diagram
```mermaid
graph TD
  Doctrine\ORM\UnitOfWork --> LegacyDependencies
  style Doctrine\ORM\UnitOfWork fill:#f9f,stroke:#333,stroke-width:4px
```

---
### [High] Critical Architectural Bottleneck in Doctrine\ORM\Mapping\ClassMetadataInfo
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: Doctrine\ORM\Mapping\ClassMetadataInfo 
- `metric`: risk_score (0.507102)
- `metric`: coupling_pressure (0.32546626755698826)



#### Topology Diagram
```mermaid
graph TD
  Doctrine\ORM\Mapping\ClassMetadataInfo --> LegacyDependencies
  style Doctrine\ORM\Mapping\ClassMetadataInfo fill:#f9f,stroke:#333,stroke-width:4px
```

---
### [High] Critical Architectural Bottleneck in Doctrine\ORM\Persisters\BasicEntityPersister
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: Doctrine\ORM\Persisters\BasicEntityPersister 
- `metric`: risk_score (0.51411)
- `metric`: coupling_pressure (0.35206078747409625)



#### Topology Diagram
```mermaid
graph TD
  Doctrine\ORM\Persisters\BasicEntityPersister --> LegacyDependencies
  style Doctrine\ORM\Persisters\BasicEntityPersister fill:#f9f,stroke:#333,stroke-width:4px
```

---
