# Master Intelligence Report: marcel_master

## 1. Executive Command Center

**Global System Meta-Data**
- **Scale:** 332 Files | 160 Classes
- **Architecture/Era:** Custom Legacy Monolith (Bespoke / Custom Era)
- **Modernization Readiness:** 29.44%
- **Test Coverage:** N/A
- **Lines of Code:** 6415
- **Connectivity:** 5446 Edges

**Architectural Footprint**
- Models: 15
- Controllers: 41
- CLI_Scripts: 31
- Schemas: 14
- Views: 94
- Vendor_Files: 19


**AI Executive Assessment**
*Current State:* Marcel is a custom PHP MVC monolith that powers a wide‑range of web features – from dynamic pages rendered with Mustache and Markdown to image manipulation, WebSocket services and background workers. The codebase consists of roughly 332 files with about 6 415 lines of PHP, organised into 15 models, 41 controllers and 94 view templates, plus a collection of CLI scripts and utility libraries. This footprint reflects a historically accumulated platform that attempts to be a one‑stop shop for many business needs, but its size and heterogenous responsibilities already hint at architectural strain.

The structural analysis shows an extreme lack of modern practices. Namespace adoption scores a flat 0.0 because every class lives in the global namespace, preventing PSR‑4 autoloading and tooling support. The file layout is therefore flat and relies on manual include paths, making refactoring fragile. The project contains a modest number of models and controllers, yet the absence of namespacing and a coherent module boundary inflates the coupling metric (14.94) and hampers independent development.

Hotspot inspection reveals three especially risky files. The image_manip component shows a WMC of 172, LCOM of 0.94, instability 0.95 and zero test coverage, indicating a very complex, poorly cohesive utility that changes frequently and is untested. Likewise, simple_html_dom_node carries a WMC of 193 and similar high instability, while the generic gitrepo file also scores high on complexity and instability. The lack of any automated tests across these hotspots magnifies the danger of regressions whenever changes are made.

Overall, the combination of obsolete PHP version constraints, missing namespaces, high coupling, and untested high‑complexity code creates a brittle foundation. Any attempt to add features or address security flaws now carries a high risk of breaking existing behaviour, and the current security score of 0.0 signals urgent need for sanitisation layers and hardened input handling. Modernisation—through platform migration, systematic refactoring and test implementation—is essential to reduce operational risk and enable sustainable growth.
*Critical Risks:* The system suffers from critical security exposure due to a security score of 0.0, meaning input handling and SQL queries lack proper sanitisation, opening the door to SQL injection attacks. Testability is also at 0.0, so no unit or integration tests exist to catch regressions, especially in the three identified hotspots where complexity and instability are extreme. The architectural coupling metric of nearly 15 indicates that changes in one area cascade throughout the codebase, making even small fixes risky. Together these dimensions create a scenario where a single change can introduce vulnerabilities, break core functionality, and remain undetected due to the absence of automated testing.
*Strategic Roadmap:* 
[{'step_number': 1, 'title': 'Establish a Modern Foundation', 'description': 'Upgrade the runtime to PHP 8.2, introduce Composer with PSR‑4 autoloading, and refactor all classes into a clear namespace hierarchy. Begin by extracting the Core / Root module into a dedicated package to serve as the base for further migration. Replace manual includes with Composer autoload to reduce coupling.', 'rationale': 'A modern runtime and autoloading eliminate the most glaring technical debt, enable use of current libraries, and lower the barrier for adding automated tests and security middleware.'}, {'step_number': 2, 'title': 'Secure the Data Layer', 'description': 'Introduce a database abstraction layer (e.g., PDO with prepared statements or an ORM) and implement input sanitisation across all controllers and models. Prioritise the modules flagged for replattforming (site, class, model) where 12 injection sinks were detected.', 'rationale': 'Addressing the security score of 0.0 removes the immediate risk of SQL injection and provides a consistent, testable data access pattern.'}, {'step_number': 3, 'title': 'Implement Automated Testing and Refactor Hotspots', 'description': 'Write unit and integration tests for the three high‑risk files (image_manip, simple_html_dom_node, gitrepo) and progressively split their responsibilities into smaller, cohesive classes. Reduce WMC by applying the single‑responsibility principle and introduce code‑coverage gates.', 'rationale': 'Testing mitigates regression risk while refactoring lowers complexity and instability, directly improving the coupling score and long‑term maintainability.'}]

## 2. Boundary Intelligence & External Surface


### Presentation Layer Coupling
- **Global UI Entanglement:** 27.7%
- **Fat Views (DB Coupled):** 4

| File | Entanglement Ratio | DB Queries | Fat View Risk |
| :--- | :--- | :--- | :--- |
| `/data/marcel-master/site/marcel/controller/cron_job.php` | 15.4% | 6 | CRITICAL |
| `/data/marcel-master/site/marcel/controller/user_type.php` | 20.0% | 6 | CRITICAL |
| `/data/marcel-master/site/marcel/controller/product_type.php` | 18.2% | 6 | CRITICAL |
| `/data/marcel-master/site/marcel/view/user_permission.all.php` | 85.2% | 1 | CRITICAL |
| `/data/marcel-master/site/marcel/view/git.log_simple_row.php` | 84.2% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/unveil.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/common.pager.php` | 81.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/app.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/script/db_schema_apply.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/script/torrent.test.php` | 33.3% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/view/mustachetest.main.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.linode.php` | 84.6% | 0 | LOW |
| `/data/marcel-master/site/angular/view/main.test.php` | 83.3% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.status.php` | 68.0% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/controller/main.circle.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/product_type.edit.php` | 87.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/view/git.status.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/authentication.php` | 14.3% | 1 | LOW |
| `/data/marcel-master/site/angular/public/js/controller/main.test.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/controller/main.bar.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/lab.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/file.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/less.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/product_category.all.php` | 85.7% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/ui.bootstrap.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/rainbow.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.status_staged.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/form_test.popover.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/json3.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.submodule.php` | 87.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/product.sub_nav.php` | 71.4% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/bootstrap.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/css/core/twilight.css` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/css/core/code.dialog.css` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/common.index.php` | 88.9% | 0 | LOW |
| `/data/marcel-master/vendor/mail_parse/examples/example2.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.xml.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/product_category.edit.php` | 87.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/product_category.view.php` | 84.8% | 0 | LOW |
| `/data/marcel-master/vendor/dom/dom.php` | 1.8% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.status_untracked.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/css/core/code.css` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/angular/view/main.bar.php` | 83.3% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/stocks.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/authentication.main.php` | 87.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.main.php` | 85.7% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/view/cart.checkout_form.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/common.debug.php` | 62.5% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/filter/numList.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.balancer.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/stock.main.php` | 91.7% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/feature.php` | 14.3% | 6 | LOW |
| `/data/marcel-master/site/marcel/view/product.table.php` | 81.8% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/common.nav_user.php` | 78.9% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.resource.php` | 91.7% | 0 | LOW |
| `/data/marcel-master/site/marcel/script/db_restore.php` | 11.1% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/user_type.edit.php` | 83.3% | 0 | LOW |
| `/data/marcel-master/site/blank/public/.htaccess` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/form.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/product.view.php` | 82.6% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/products.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/user_types.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.submodules.php` | 71.4% | 0 | LOW |
| `/data/marcel-master/vendor/usps/demos/citystatelookup.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.html.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.plans.php` | 71.4% | 0 | LOW |
| `/data/marcel-master/site/angular/view/main.nav.php` | 77.8% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/git.php` | 7.3% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.init.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/angular/view/main.index.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/product_type.all.php` | 85.7% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/directive/ngTap.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.balancers.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/view/message.main.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/cart.main.php` | 87.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/user.php` | 11.8% | 6 | LOW |
| `/data/marcel-master/site/marcel/controller/product.php` | 12.5% | 6 | LOW |
| `/data/marcel-master/site/marcel/view/mustachetest.main.php` | 87.5% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/app.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/worker.view.php` | 82.4% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/product.all.php` | 82.9% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.domain.php` | 85.7% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/common.nav.php` | 84.7% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/loader.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.branch.php` | 80.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/json.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/css/core/github.css` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/cart.php` | 2.8% | 9 | LOW |
| `/data/marcel-master/site/marcel/view/feature.all.php` | 86.2% | 0 | LOW |
| `/data/marcel-master/class/torrent.php` | 2.6% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/email.incoming_test.php` | 92.3% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/factory/testFactory.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/file_manager.edit.php` | 80.0% | 0 | LOW |
| `/data/marcel-master/vendor/usps/demos/domestic_rate.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/user_type.view.php` | 84.6% | 0 | LOW |
| `/data/marcel-master/vendor/usps/demos/address_verify.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/common.nav_admin.php` | 75.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.dialog.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/class/cli_helper.php` | 43.8% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/carts.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/workers.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/feature.table.php` | 84.6% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.origin.php` | 78.9% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.linodes.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/form_test.index.php` | 66.7% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.vim.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/blank/view/layout/a.php` | 87.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/typeahead.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/vendor/usps/demos/trackconfirm.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.log_simple.php` | 66.7% | 0 | LOW |
| `/data/marcel-master/site/angular/public/.htaccess` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.status_modified.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/cart.view.php` | 85.7% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.branches.php` | 75.0% | 0 | LOW |
| `/data/marcel-master/vendor/usps/demos/zipcodelookup.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/angular/view/layout/a.php` | 88.9% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/user.email_join.php` | 75.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/cron_jobs.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/layout/a.php` | 94.4% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/hogan.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/feature.view.php` | 84.6% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/user_permissions.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/vendor/image_manip.php` | 1.1% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.javascript.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.notification.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/user.all.php` | 85.2% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.search.cursor.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/file_manager.main.php` | 87.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/user.edit.php` | 83.3% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/message.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/product_categories.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.css.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/cron_job.all.php` | 84.2% | 0 | LOW |
| `/data/marcel-master/site/angular/view/main.modal.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/email_threads.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/.htaccess` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/filter/fuzzy.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/css/core/screen.css` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/script/program.example.php` | 25.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/crossdomain.xml` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/cron_job.view.php` | 84.4% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/user.table.php` | 88.2% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/validate.min.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/user_type.all.php` | 84.2% | 0 | LOW |
| `/data/marcel-master/site/marcel/script/vim.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/fastclick.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.php.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/common.nav_test.php` | 84.6% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/factory/abcFactory.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/class/app.php` | 6.9% | 0 | LOW |
| `/data/marcel-master/class/helper.php` | 13.3% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/user_verifications.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.plan.php` | 92.9% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.status_deleted.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/product_category.php` | 14.3% | 6 | LOW |
| `/data/marcel-master/site/marcel/view/product.edit.php` | 87.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/users.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/worker.nav_filter.php` | 66.7% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/bootstrap.min.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/file_manager.php` | 12.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/product_types.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/file_manager.view.php` | 80.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/file_manager.explorer.php` | 71.4% | 0 | LOW |
| `/data/marcel-master/site/angular/view/main.circle.php` | 75.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/cron_job.edit.php` | 83.3% | 0 | LOW |
| `/data/marcel-master/class/socket_server.php` | 5.2% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/common.php` | 10.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/product_type.view.php` | 82.8% | 0 | LOW |
| `/data/marcel-master/class/clicolor.php` | 28.6% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.domains.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/user.view.php` | 80.6% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/linode.resources.php` | 71.4% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/websocket.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/wysiwyg.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/form_test.modal.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/worker.all.php` | 75.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/file_manager.explorer_file.php` | 87.5% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/features.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.main.php` | 86.7% | 0 | LOW |
| `/data/marcel-master/site/marcel/script/create_user.php` | 11.1% | 2 | LOW |
| `/data/marcel-master/site/marcel/view/common.nav_collapse.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/angular/public/js/service/testService.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/script/db_init.php` | 13.3% | 0 | LOW |
| `/data/marcel-master/site/marcel/db/schema/sessions.sql` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/git.file.php` | 79.2% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.clike.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/common.output_style.php` | 92.9% | 0 | LOW |
| `/data/marcel-master/site/marcel/public/js/html.shiv.js` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/filter.main.php` | 79.2% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/feature.edit.php` | 83.3% | 0 | LOW |
| `/data/marcel-master/site/marcel/controller/ocr.php` | 50.0% | 0 | LOW |
| `/data/marcel-master/site/marcel/view/message.main.php` | 83.3% | 0 | LOW |


### API & Endpoint Surface
- **Total Endpoints:** 179

| Entry Point | Classification |
| :--- | :--- |
| `/data/marcel-master/site/marcel/view/git.log_simple_row.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/unveil.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/common.pager.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/app.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/script/db_schema_apply.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/script/torrent.test.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/view/mustachetest.main.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.linode.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/view/main.test.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.status.php` | Server-Rendered Page |
| `/data/marcel-master/class/route.php` | API Endpoint |
| `/data/marcel-master/site/angular/public/js/controller/main.circle.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product_type.edit.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/view/git.status.js` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/controller/main.test.js` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/controller/main.bar.js` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/lab.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/file.js` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/less.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product_category.all.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/ui.bootstrap.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/rainbow.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.status_staged.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/form_test.popover.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/json3.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.submodule.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product.sub_nav.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/bootstrap.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/css/core/twilight.css` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/css/core/code.dialog.css` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/common.index.php` | Server-Rendered Page |
| `/data/marcel-master/vendor/mail_parse/examples/example2.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.xml.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/script/chat_server.php` | API Endpoint |
| `/data/marcel-master/site/marcel/view/product_category.edit.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product_category.view.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.status_untracked.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/css/core/code.css` | Server-Rendered Page |
| `/data/marcel-master/site/angular/view/main.bar.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/stocks.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/authentication.main.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.main.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/view/cart.checkout_form.js` | Server-Rendered Page |
| `/data/marcel-master/class/model.php` | API Endpoint |
| `/data/marcel-master/site/marcel/view/common.debug.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/filter/numList.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.balancer.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/stock.main.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product.table.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/common.nav_user.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.resource.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/script/db_restore.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/user_type.edit.php` | Server-Rendered Page |
| `/data/marcel-master/site/blank/public/.htaccess` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/form.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product.view.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/products.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/user_types.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.submodules.php` | Server-Rendered Page |
| `/data/marcel-master/vendor/usps/demos/citystatelookup.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.html.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.plans.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/view/main.nav.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.init.js` | Server-Rendered Page |
| `/data/marcel-master/site/angular/view/main.index.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product_type.all.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/directive/ngTap.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.balancers.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/view/message.main.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/cart.main.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/user_permission.all.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/mustachetest.main.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/app.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/worker.view.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product.all.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.domain.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/common.nav.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/loader.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.branch.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/json.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/css/core/github.css` | Server-Rendered Page |
| `/data/marcel-master/model/User_Permission.php` | API Endpoint |
| `/data/marcel-master/site/marcel/controller/cart.php` | API Endpoint |
| `/data/marcel-master/site/marcel/view/feature.all.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/email.incoming_test.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/factory/testFactory.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/file_manager.edit.php` | Server-Rendered Page |
| `/data/marcel-master/vendor/usps/demos/domestic_rate.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/user_type.view.php` | Server-Rendered Page |
| `/data/marcel-master/vendor/usps/demos/address_verify.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/common.nav_admin.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.dialog.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/carts.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/workers.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/feature.table.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.origin.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.linodes.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/form_test.index.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.vim.js` | Server-Rendered Page |
| `/data/marcel-master/site/blank/view/layout/a.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/typeahead.js` | Server-Rendered Page |
| `/data/marcel-master/vendor/usps/demos/trackconfirm.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.log_simple.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/.htaccess` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.status_modified.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/cart.view.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.branches.php` | Server-Rendered Page |
| `/data/marcel-master/vendor/usps/demos/zipcodelookup.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/view/layout/a.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/user.email_join.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/cron_jobs.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/layout/a.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/hogan.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/feature.view.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/user_permissions.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.javascript.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.notification.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/user.all.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.search.cursor.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/file_manager.main.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/user.edit.php` | Server-Rendered Page |
| `/data/marcel-master/model/Stock.php` | API Endpoint |
| `/data/marcel-master/site/marcel/db/schema/product_categories.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.css.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/cron_job.all.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/view/main.modal.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/email_threads.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/.htaccess` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/filter/fuzzy.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/css/core/screen.css` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/script/program.example.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/crossdomain.xml` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/cron_job.view.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/user.table.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/validate.min.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/user_type.all.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/script/vim.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/fastclick.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.php.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/common.nav_test.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/factory/abcFactory.js` | Server-Rendered Page |
| `/data/marcel-master/class/helper.php` | API Endpoint |
| `/data/marcel-master/site/marcel/db/schema/user_verifications.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.plan.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.status_deleted.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product.edit.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/users.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/worker.nav_filter.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/bootstrap.min.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/product_types.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/file_manager.view.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/file_manager.explorer.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/view/main.circle.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/cron_job.edit.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/product_type.view.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.domains.php` | Server-Rendered Page |
| `/data/marcel-master/model/Cart.php` | API Endpoint |
| `/data/marcel-master/site/marcel/view/user.view.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/linode.resources.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/websocket.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/wysiwyg.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/form_test.modal.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/worker.all.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/file_manager.explorer_file.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/features.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.main.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/script/create_user.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/common.nav_collapse.php` | Server-Rendered Page |
| `/data/marcel-master/site/angular/public/js/service/testService.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/script/db_init.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/db/schema/sessions.sql` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/git.file.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/class/code.mode.clike.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/common.output_style.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/public/js/html.shiv.js` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/filter.main.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/feature.edit.php` | Server-Rendered Page |
| `/data/marcel-master/site/marcel/view/message.main.php` | Server-Rendered Page |


### Vendor & Shadow IT Intelligence
- **Vendor Files Scanned:** 19

| File | Vendor Type | Status |
| :--- | :--- | :--- |
| `/data/marcel-master/vendor/usps/USPSTrackConfirm.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/USPSAddressVerify.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/USPSRate.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/USPSAddress.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/mail_parse/examples/example1.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/mail_parse/examples/example2.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/dom/dom.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/demos/citystatelookup.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/demos/domestic_rate.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/demos/address_verify.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/mail_parse/MimeMailParser.class.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/demos/trackconfirm.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/demos/zipcodelookup.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/image_manip.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/mail_parse/attachment.class.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/USPSCityStateLookup.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/USPSZipCodeLookup.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/XMLParser.php` | Composer Vendor | 🟢 OK |
| `/data/marcel-master/vendor/usps/USPSBase.php` | Composer Vendor | 🟢 OK |



## 3. Layered Architecture & Topology


- **Presentation vs. Logic Ratio:** 52.87009063444109% of classified files are UI/Routing related.

### Bounded Contexts
| Domain Name | Files | Internal Calls | External Calls | Coupling Ratio | DB Access | Auth Access |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `Site: Marcel` | 197 | 0 | 0 | 424.0 | False | False |
| `Global` | 160 | 0 | 0 | 0.0 | False | False |
| `Site: Blank` | 7 | 0 | 0 | 5.0 | False | False |
| `class` | 63 | 0 | 0 | 90.0 | False | False |
| `Site: Angular` | 26 | 0 | 0 | 7.0 | False | False |
| `model` | 15 | 0 | 0 | 17.0 | False | False |
| `tmp` | 1 | 0 | 0 | 1.0 | False | False |


*(Note: The full interactive system topology graph is available in the accompanying `index.html` application or raw `raw_data/graph_2.json` export).*


## 4. Database & State Intelligence

| Table Name | Write Intensity | Shared Pressure |
| :--- | :--- | :--- |
| `` |  |  |
| `` |  |  |
| `` |  |  |
| `` |  |  |
| `` |  |  |


## 5. Risk Audit & Remediation

### [High] Critical Architectural Bottleneck in gitrepo
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: gitrepo 
- `metric`: risk_score (0.627994)
- `metric`: coupling_pressure (0.31141439205955335)



#### Topology Diagram
```mermaid
graph TD
  gitrepo --> LegacyDependencies
  style gitrepo fill:#f9f,stroke:#333,stroke-width:4px
```

---
### [High] Critical Architectural Bottleneck in image_manip
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: image_manip 
- `metric`: risk_score (0.485012)
- `metric`: coupling_pressure (0.20790499822757888)



#### Topology Diagram
```mermaid
graph TD
  image_manip --> LegacyDependencies
  style image_manip fill:#f9f,stroke:#333,stroke-width:4px
```

---
### [High] Critical Architectural Bottleneck in simple_html_dom_node
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: simple_html_dom_node 
- `metric`: risk_score (0.392625)
- `metric`: coupling_pressure (0.3709677419354839)



#### Topology Diagram
```mermaid
graph TD
  simple_html_dom_node --> LegacyDependencies
  style simple_html_dom_node fill:#f9f,stroke:#333,stroke-width:4px
```

---
### [High] Critical Architectural Bottleneck in simple_html_dom
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: simple_html_dom 
- `metric`: risk_score (0.307507)
- `metric`: coupling_pressure (0.2990074441687345)



#### Topology Diagram
```mermaid
graph TD
  simple_html_dom --> LegacyDependencies
  style simple_html_dom fill:#f9f,stroke:#333,stroke-width:4px
```

---
### [High] Critical Architectural Bottleneck in controller_git
- **Business Impact:** Tight coupling prevents modular extraction and makes automated testing virtually impossible.
- **Strategic Action:** Isolate dependencies behind an interface. Write characterization tests before attempting extraction. *(Confidence: Probable)*
- **Evidence/Metrics:**
- `file`: controller_git 
- `metric`: risk_score (0.354066)
- `metric`: coupling_pressure (0.5023041474654378)



#### Topology Diagram
```mermaid
graph TD
  controller_git --> LegacyDependencies
  style controller_git fill:#f9f,stroke:#333,stroke-width:4px
```

---
